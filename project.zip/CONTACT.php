<!DOCTYPE html>
<html lang="en">
<head>
  <title>MOVIES</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  
  <link rel="stylesheet" href="css/mycss.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
  
 <!--<script >
  	 $(document).ready(function() {
    $('#contact_form').bootstrapValidator({
        
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            full_name: {
                validators: {
                        stringLength: {
                        min: 5,
                    },
                        notEmpty: {
                        message: 'Please supply your Full Name'
                    }
                }
            },
             email: {
                validators: {
                    notEmpty: {
                        message: 'Please supply your email address'
                    },
                    emailAddress: {
                        message: 'Please supply a valid email address'
                    }
                }
            },
            
        };
});
});

  </script>-->
  <script>
  		function formValidation()  
		{  
			var uname = document.registration.username; 
			var uemail = document.registration.email;  
			if(allLetter(uname))  
				{
			if(ValidateEmail(uemail))  
				{
				}
				}
				return false;
		}		  	  

		  	function allLetter(uname)  
		{   
		var letters = /^[A-Za-z]+$/;  
		if(uname.value.match(letters))  
		{  
		return true;  
		}  
		else  
		{  
		alert('Username must have alphabet characters only');  
		uname.focus();  
		return false;  
		}  
		}  

		function ValidateEmail(uemail)  
		{  
		var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;  
		if(uemail.value.match(mailformat))  
		{  
		return true;  
		}  
		else  
		{  
		alert("You have entered an invalid email address!");  
		uemail.focus();  
		return false;  
		}  
		}  
  </script>
</head>
<body onload="document.registration.userid.focus();">


	<nav class="navbar navbar-default navbar-static-top" style="height:70px;background-color:#252429;">
  		<div class="container-fluid"  > 
    <div class="container">
    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse" >
        <span class="sr-only"></span>
		<span class="icon-bar"></span>
		<span class="icon-bar"></span>
		<span class="icon-bar"></span>
	</button>
      <a  id="nav" class="navbar-brand" href="#">My Web</a>  
       <div class="navbar-collapse collapse" style="background-color:#252429;">
        <ul class="nav navbar-nav navbar-right">
		  <li ><a id="nav" href="index.php">HOME</a></li>
		  <li ><a  id="nav" href="MOVIES.php">MOVIES</a></li>
		  <li ><a id="nav" href="VIDEOS.php">VIDEOS</a></li>
		  <li ><a id="nav" href="SERIES.php">SERIES</a></li>
		  
		  <li class="active"><a id="nav" href="CONTACT.php">CONTACT</a></li>
		  <li ><a id="nav" href="LOGIN.php">LOGIN/SIGNUP</a></li>
		  
		
		</ul>
         </div>		
  </div>
  </div>
</nav>
<div class="container">
<div class="row" align="center">
<h2>Contact Us</h2>
</div>
<div class="row" style="height:450px;">
<div class="col-md-6" >
  <form name="registration" id="contact_form" onSubmit="return formValidation();" style="margin-top:40px;">  
		
  		    <div  id="validateform">
  					
  					<div class="form-group">	
  						<div class="input-group">
  						<span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
  						<input type="text" name="username" placeholder="Name" class="form-control">
  						</div>
  					</div>
					<p>
					</br>
					
					</p>

  					<div class="form-group">
  						
  						<div class="input-group">
	  						<span class="input-group-addon"><i class="glyphicon glyphicon-envelope"></i></span>
	  						<input type="text" name="email" placeholder="example@xyz.com" class="form-control">
	  					</div>
  					</div>
					<p>
					</br>
					
					</p>

  					<div class="form-group">	
  						
  						<div class="input-group">
  							<span class="input-group-addon"><i class="glyphicon glyphicon-pencil"></i></span>
  							<textarea class="form-control" rows="5"  name="comment" placeholder="Your Message"></textarea>
  						</div>
  						
					</div>
					<p>
					</br>
					
					</p>
					
		
					<div class="form-group" align="center">
						<button type="submit" class="btn btn-success " >Submit</button>
					</div>
  				</div>
  				
			
  		
  		</form>   

</div>
   <div class="col-md-6 col-xs-12"  style="margin-top:100px;">
    <a href="#"> 
	<div class="glyphicon glyphicon-home" ></div>
	
	 <label >&nbspG.L Bajaj Institute Of Technology & Management,Greater Noida</label>
	 </a>
	 
	 
	<a href="#"> 
	</br>
		<div class="glyphicon glyphicon-envelope" >
		</div>
	 <label >&nbspsaumyajaiswal50@gmail.com &nbsp, anamikadolly16@gmail.com</label>
	 </a>
	 
     <div >
	    <a href="#">
		 <i class="fa fa-facebook-square" style="font-size:20px;color:#3b5998;"></i>
		 <label>&nbspFacebook</label>
		
		</a>
	 </div>
   
   
    <div >
	    <a href="#">
	      <i class="fa fa-google-plus-official" style="font-size:20px;color:#dd4b39;"></i>
		 <label>&nbspGoogle Plus</label>
		
		</a>
	 </div>
	 <div >
	    <a href="#">
	      <i class="fa fa-twitter" style="font-size:20px;color:#00aced;"></i>
		 <label>&nbspTwitter</label>
		
		</a>
	 </div>
  






</div>



</div>

</div>

<!--footer-->

 
  
  
<div  style="background-color:black;height:100px;color:white;">
  <div align="center" style="padding:10px;color:white;">
 
		  <label class="active"><a  href="#">Home</a></label>
		   <label ><a   href="MOVIES.php">Movies</a></label>
		   <label ><a href="VIDIOS.php">Videos</a></label>
		   <label ><a href="SERIES.php">Series</a></label>
		  
		  <label ><a  href="CONTACT.php">Contact</a></label>
		  
		
		
		</div>

  <div align="center"class="back-to-top-link"><a href="#top" id="myBtn" ><span class="arrow"></span>Top</a></div>
  
    <div align="center">
         <p>copyright myweb 2017</p>
    
  </div>
</div>

</body>
</html>








