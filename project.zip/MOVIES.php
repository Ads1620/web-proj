<!DOCTYPE html>
<html lang="en">
<head>
  <title>MOVIES</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" href="css/mycss.css">
  
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  
</head>
<body style="background-color:#f8f7ff;">
<nav class="navbar navbar-default navbar-static-top" style="height:70px;background-color:#252429;">
  		<div class="container-fluid"  > 
    <div class="container">
    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse" >
        <span class="sr-only"></span>
		<span class="icon-bar"></span>
		<span class="icon-bar"></span>
		<span class="icon-bar"></span>
	</button>
      <a  id="nav" class="navbar-brand" href="#">My Web</a>  
       <div class="navbar-collapse collapse" style="background-color:#252429;">
        <ul class="nav navbar-nav navbar-right">
		  <li ><a id="nav" href="index.php">HOME</a></li>
		  <li class="active"><a  id="nav" href="MOVIES.php">MOVIES</a></li>
		  <li ><a id="nav" href="VIDEOS.php">VIDEOS</a></li>
		  <li ><a id="nav" href="SERIES.php">SERIES</a></li>
		  
		  <li ><a id="nav" href="CONTACT.php">CONTACT</a></li>
		  <li ><a id="nav" href="LOGIN.php">LOGIN/SIGNUP</a></li>
		  
		
		</ul>
         </div>		
  </div>
  </div>
</nav>
<div class="container">
    <div>  
	    <h3>Bollywood Movies</h3>
	</div>
	  <div class="row">
			    <div class="col-md-3 col-xs-6">
				 <a href="MOVIESNAME.php" ><div class="thumbnail">
				  <img id="imgtag"src="images/5.jpg" >
				  <div class="caption">
			       <p>Yjhd</p>
			      </div>
				 </div></a>
			 </div> 
			 <div class="col-md-3 col-xs-6">
				  <div class="thumbnail">
				  <img id="imgtag"src="images/7.jpg" >
				  <div class="caption">
			       <p>Baajirao Mastani</p>
			      </div>
				 </div>
			 </div> 
			  <div class="col-md-3 col-xs-6">
				  <div class="thumbnail">
				  <img id="imgtag"src="images/16.jpg" >
				  <div class="caption">
			       <p>Baajirao Mastani</p>
			      </div>
				 </div>
			 </div> 
			  <div class="col-md-3 col-xs-6">
				  <div class="thumbnail">
				  <img id="imgtag" src="images/18.jpg" >
				  <div class="caption">
			       <p>Cocktail</p>
			      </div>
				 </div>
			 </div> 
		</div>
		<div class="row">
			    <div class="col-md-3 col-xs-6">
				 <a href="MOVIESNAME.php" ><div class="thumbnail">
				  <img id="imgtag"src="images/19.jpg" >
				  <div class="caption">
			       <p>Yeh Jawani </p>
			      </div>
				 </div></a>
			 </div> 
			  <div class="col-md-3 col-xs-6">
				  <div class="thumbnail">
				  <img id="imgtag"src="images/20.jpg" >
				  <div class="caption">
			       <p>Baajirao Mastani</p>
			      </div>
				 </div>
			 </div> 
			  <div class="col-md-3 col-xs-6">
				  <div class="thumbnail">
				  <img id="imgtag"src="images/21.jpg" >
				  <div class="caption">
			       <p>Baajirao Mastani</p>
			      </div>
				 </div>
			 </div> 
			  <div class="col-md-3 col-xs-6">
				  <div class="thumbnail">
				  <img id="imgtag"src="images/22.jpg" >
				  <div class="caption">
			       <p>Cocktail</p>
			      </div>
				 </div>
			 </div> 
		</div>
		<div class="row">
			    <div class="col-md-3 col-xs-6">
				 <a href="MOVIESNAME.php" ><div class="thumbnail">
				  <img id="imgtag" src="images/23.jpg" >
				  <div class="caption">
			       <p>Yeh Jawani </p>
			      </div>
				 </div></a>
			 </div> 
			  <div class="col-md-3 col-xs-6">
				  <div class="thumbnail">
				  <img id="imgtag"src="images/24.jpg" >
				  <div class="caption">
			       <p>Baajirao Mastani</p>
			      </div>
				 </div>
			 </div> 
			  <div class="col-md-3 col-xs-6">
				  <div class="thumbnail">
				  <img id="imgtag"src="images/25.jpg" >
				  <div class="caption">
			       <p>Baajirao Mastani</p>
			      </div>
				 </div>
			 </div> 
			  <div class="col-md-3 col-xs-6">
				  <div class="thumbnail">
				  <img id="imgtag"src="images/26.jpg">
				  <div class="caption">
			       <p>Cocktail</p>
			      </div>
				 </div>
			 </div> 
		</div>
		<div class="row">
			    <div class="col-md-3 col-xs-6">
				 <a href="MOVIESNAME.php" ><div class="thumbnail">
				  <img id="imgtag"src="images/27.jpg" >
				  <div class="caption">
			       <p>Yeh Jawani </p>
			      </div>
				 </div></a>
			 </div> 
			  <div class="col-md-3 col-xs-6">
				  <div class="thumbnail">
				  <img id="imgtag"src="images/28.jpg" >
				  <div class="caption">
			       <p>Baajirao Mastani</p>
			      </div>
				 </div>
			 </div> 
			  <div class="col-md-3 col-xs-6">
				  <div class="thumbnail">
				  <img id="imgtag"src="images/29.jpg" >
				  <div class="caption">
			       <p>Baajirao Mastani</p>
			      </div>
				 </div>
			 </div> 
			  <div class="col-md-3 col-xs-6">
				  <div class="thumbnail">
				  <img id="imgtag"src="images/30.jpg" >
				  <div class="caption">
			       <p>Cocktail</p>
			      </div>
				 </div>
			 </div> 
		</div>




</div>
<div  style="background-color:black;height:100px;color:white;">
  <div align="center" style="padding:10px;color:white;">
 
		  <label class="active"><a  href="#">Home</a></label>
		   <label ><a   href="MOVIES.php">Movies</a></label>
		   <label ><a href="VIDIOS.php">Videos</a></label>
		   <label ><a href="SERIES.php">Series</a></label>
		  
		  <label ><a  href="CONTACT.php">Contact</a></label>
		  
		  
		
		
		</div>

  <div align="center"class="back-to-top-link"><a href="#top" id="myBtn" ><span class="arrow"></span>Top</a></div>
  
    <div align="center">
         <p>copyright myweb 2017</p>
    
  </div>
</div>

</body>
</html>
