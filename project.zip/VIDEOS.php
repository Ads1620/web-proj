<!DOCTYPE html>
<html lang="en">
<head>
  <title>VIDEOS</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" href="css/mycss.css">
 
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  
	  
</head>
<body style="background-color:#f8f7ff;">
<nav class="navbar navbar-default navbar-static-top" style="height:70px;background-color:#252429;">
  		<div class="container-fluid"  > 
    <div class="container">
    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse" >
        <span class="sr-only"></span>
		<span class="icon-bar"></span>
		<span class="icon-bar"></span>
		<span class="icon-bar"></span>
	</button>
      <a  id="nav" class="navbar-brand" href="#">My Web</a>  
       <div class="navbar-collapse collapse" style="background-color:#252429;">
        <ul class="nav navbar-nav navbar-right">
		  <li ><a id="nav" href="index.php">HOME</a></li>
		  <li ><a  id="nav" href="MOVIES.php">MOVIES</a></li>
		  <li class="active"><a id="nav" href="VIDEOS.php">VIDEOS</a></li>
		  <li ><a id="nav" href="SERIES.php">SERIES</a></li>
		  
		  <li ><a id="nav" href="CONTACT.php">CONTACT</a></li>
		  <li ><a id="nav" href="LOGIN.php">LOGIN/SIGNUP</a></li>
		  
		
		</ul>
         </div>		
  </div>
  </div>
</nav>
<div class="container">
    <div>  
	    <h3>Videos</h3>
	</div>
	  <div class="row">
			    <div class="col-md-3 col-xs-6">
				 <a href="MOVIESNAME.php" ><div class="thumbnail">
				  <img id="imgtag"src="videos/1.jpg" >
				  <div class="caption">
			       <p>YJHD</p>
			      </div>
				 </div></a>
			 </div> 
			 <div class="col-md-3 col-xs-6">
				  <div class="thumbnail">
				  <img id="imgtag"src="videos/2.jpg" >
				  <div class="caption">
			       <p>Baajirao Mastani</p>
			      </div>
				 </div>
			 </div> 
			  <div class="col-md-3 col-xs-6">
				  <div class="thumbnail">
				  <img id="imgtag"src="videos/3.jpg" >
				  <div class="caption">
			       <p>Baajirao Mastani</p>
			      </div>
				 </div>
			 </div> 
			  <div class="col-md-3 col-xs-6">
				  <div class="thumbnail">
				  <img id="imgtag" src="videos/19.jpg" >
				  <div class="caption">
			       <p>Cocktail</p>
			      </div>
				 </div>
			 </div> 
		</div>
		<div class="row">
			    <div class="col-md-3 col-xs-6">
				 <a href="MOVIESNAME.php" ><div class="thumbnail">
				  <img id="imgtag"src="videos/5.jpg" >
				  <div class="caption">
			       <p>YJHD</p>
			      </div>
				 </div></a>
			 </div> 
			  <div class="col-md-3 col-xs-6">
				  <div class="thumbnail">
				  <img id="imgtag"src="videos/6.jpg" >
				  <div class="caption">
			       <p>Baajirao Mastani</p>
			      </div>
				 </div>
			 </div> 
			  <div class="col-md-3 col-xs-6">
				  <div class="thumbnail">
				  <img id="imgtag"src="videos/8.jpg" >
				  <div class="caption">
			       <p>Baajirao Mastani</p>
			      </div>
				 </div>
			 </div> 
			  <div class="col-md-3 col-xs-6">
				  <div class="thumbnail">
				  <img id="imgtag"src="videos/9.jpg" >
				  <div class="caption">
			       <p>Cocktail</p>
			      </div>
				 </div>
			 </div> 
		</div>
		<div class="row">
			    <div class="col-md-3 col-xs-6">
				 <a href="MOVIESNAME.php" ><div class="thumbnail">
				  <img id="imgtag" src="videos/10.jpg" >
				  <div class="caption">
			       <p>YJHD</p>
			      </div>
				 </div></a>
			 </div> 
			  <div class="col-md-3 col-xs-6">
				  <div class="thumbnail">
				  <img id="imgtag"src="videos/11.jpg" >
				  <div class="caption">
			       <p>Baajirao Mastani</p>
			      </div>
				 </div>
			 </div> 
			  <div class="col-md-3 col-xs-6">
				  <div class="thumbnail">
				  <img id="imgtag"src="videos/12.jpg" >
				  <div class="caption">
			       <p>Baajirao Mastani</p>
			      </div>
				 </div>
			 </div> 
			  <div class="col-md-3 col-xs-6">
				  <div class="thumbnail">
				  <img id="imgtag"src="videos/13.jpg">
				  <div class="caption">
			       <p>Cocktail</p>
			      </div>
				 </div>
			 </div> 
		</div>
		<div class="row">
			    <div class="col-md-3 col-xs-6">
				 <a href="MOVIESNAME.php" ><div class="thumbnail">
				  <img id="imgtag"src="videos/14.jpg" >
				  <div class="caption">
			       <p>YJHD</p>
			      </div>
				 </div></a>
			 </div> 
			  <div class="col-md-3 col-xs-6">
				  <div class="thumbnail">
				  <img id="imgtag"src="videos/15.jpg" >
				  <div class="caption">
			       <p>Baajirao Mastani</p>
			      </div>
				 </div>
			 </div> 
			  <div class="col-md-3 col-xs-6">
				  <div class="thumbnail">
				  <img id="imgtag"src="videos/16.jpg" >
				  <div class="caption">
			       <p>Baajirao Mastani</p>
			      </div>
				 </div>
			 </div> 
			  <div class="col-md-3 col-xs-6">
				  <div class="thumbnail">
				  <img id="imgtag"src="videos/17.jpg" >
				  <div class="caption">
			       <p>Cocktail</p>
			      </div>
				 </div>
			 </div> 
		</div>




</div>
<div  style="background-color:black;height:100px;color:white;">
  <div align="center" style="padding:10px;color:white;">
 
		  <label class="active"><a  href="#">Home</a></label>
		   <label ><a   href="MOVIES.php">Movies</a></label>
		   <label ><a href="VIDIOS.php">Videos</a></label>
		   <label ><a href="SERIES.php">Series</a></label>
		  
		  <label ><a  href="CONTACT.php">Contact</a></label>
		  
		  
		
		
		</div>

  <div align="center"class="back-to-top-link"><a href="#top" id="myBtn" ><span class="arrow"></span>Top</a></div>
  
    <div align="center">
         <p>copyright myweb 2017</p>
    
  </div>
</div>

</body>
</html>
