<!DOCTYPE html>
<html lang="en">
<head>
  <title>YEH JAWANI HAI DEEWANI</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" href="css/mycss.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body >


	<!--navbar-->  

 <nav class="navbar navbar-default navbar-static-top" style="height:70px;background-color:#252429;">
  		<div class="container-fluid"  > 
    <div class="container">
    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse" >
        <span class="sr-only"></span>
		<span class="icon-bar"></span>
		<span class="icon-bar"></span>
		<span class="icon-bar"></span>
	</button>
      <a  id="nav" class="navbar-brand" href="#">My Web</a>  
       <div class="navbar-collapse collapse" style="background-color:#252429;">
        <ul class="nav navbar-nav navbar-right">
		  <li ><a id="nav" href="index.php">HOME</a></li>
		  <li ><a  id="nav" href="MOVIES.php">MOVIES</a></li>
		  <li ><a id="nav" href="VIDEOS.php">VIDEOS</a></li>
		  <li ><a id="nav" href="SERIES.php">SERIES</a></li>
		  
		  <li ><a id="nav" href="CONTACT.php">CONTACT</a></li>
		  <li ><a id="nav" href="LOGIN.php">LOGIN/SIGNUP</a></li>
		  
		
		</ul>
         </div>		
  </div>
  </div>
</nav>
  
<div class="container">
  	
  		<div class="row">
  			<div class="col-md-12 col-xs-12" >
  				<img src="images/33.jpg"  style="width:100%;  height: 370px;" >
  			</div>
  		</div>
  		<div class="row">
  			<div class="col-md-12 col-xs-12">
  				<div class="well" style="margin-top: 2px;">
		    		<h3>Movie Name</h3>
		    		<div class="row">
		    			<div class="col-md-2 col-xs-4">
		    					<button type="button" class="btn btn-default btn-sm">Category</button>
		    			</div>
		    			<div class="col-md-3 col-xs-6">
		    					<button type="button" class="btn btn-default btn-sm" >Bollywood</button>
		    			</div>
		    			<div class="col-md-7 col-xs-12">
		    					<p>Released on:DD/MM/YY . 2hr 35min</p>
		    			</div>
		    		</div>
		    		
	  		    </div>
  			</div>
  		</div>
  		<div class="row">
  			<div class="col-md-1 col-xs-4">
  				<button type="button" class="btn btn-success bt-lg">Download</button>
  			</div>
  			<div class="col-md-6 col-xs-6">
  				<button type="button" class="btn btn-info bt-xs">720p</button>
  			</div>
  		</div>	

  		<div class="row" style="margin-top: 5px;">
  			<div class="col-md-1 col-xs-4">
  				<button type="button" class="btn btn-success bt-lg">Download</button>
  			</div>
  			<div class="col-md-6 col-xs-6">
  				<button type="button" class="btn btn-info bt-xs">1080p</button>
  			</div>
  		</div>	
  		

	    <div>
	    	<h4><strong>Synopsis</strong></h4>
	    	<p>
			Yeh Jawaani Hai Deewani (English: This Youth is Crazy), is a 2013 Indian romantic comedy-drama film, written and directed by Ayan Mukerji
			and produced by Karan Johar.It stars Ranbir Kapoor and Deepika Padukone in lead roles. This is their second film together after 2008's Bachna
			Ae Haseeno. Kalki Koechlin and Aditya Roy Kapur play supporting roles. Madhuri Dixit appears in an item number with Ranbir Kapoor. Initially set 
			
			
			</p>
			<p>
			  Nainwithe the wedding, Kabir sees Naina with another man, Vikrdecision in the future. However, Kabir says that he is happy with Naina and wants to continue travelling but with her. He argues that somehow 
			  they can make a life together. Naina agrees. Kabir and Naina then get engaged and finally declare their love properly for one another. They h
			  ave a conference call between Aditi and Avi. Avi is at his bar which is successfuly running and Aditi is at the airport as a newlywed leaving 
			  for her honeymoon to Venice with Taran. The friends find out about Kabir and Naina and are overwhelmed. Aditi states that she always kind of kn
			  
			</p>
			<p>
			
			  am (Rariend, but Kabir assumes him to be her boyfriend, feels jealous and argues with him, finally sending him away. Kabir and Naina meet, 
			  argue, and reveal their feelings by a kiss. Yet neither of them is willing to give up a career to follow the other. It seems that their roman
			  ce is over. Kabir also confronts Aditi on her past crush on Avi. She admits that she had feelings for Avi but says that she has gotten over h
			  im and is extremely happy with Taran. Kabir leaves for home on the night of Aditi's wedding and will leave for Paris three weeks later for his
			 
			</p>
			
			
	    </div>
			
			
			
			<div class="container">

			<div class="row">
				<div class="col-md-3 col-xs-6">
					<h3>Picture Quality</h3>
				</div>
			</div>
  
			<div class="row">
				<div class="col-md-3 col-xs-6">
			
					<div >
                        <img id="imgtag" src="images/16.jpg">
            		 </div>

				</div>

				<div class="col-md-3 col-xs-6 ">
						
					<div >
		                        <img id="imgtag"  src="images/16.jpg">
		             </div>

				</div>

				<div class="col-md-3 col-xs-6">
					
					<div >
		                        <img id="imgtag"  src="images/16.jpg">
		                        
		             </div>

				</div>

				<div class="col-md-3 col-xs-6">
					
					<div >
		                        <img id="imgtag" src="images/16.jpg" >
		                        
		             </div>

				</div>
	        </div>
	        

	    </div>
	   



    </br>
	</br>

  

</div><!-- container div close-->


    

<div  style="background-color:black;height:100px;color:white;">
  <div align="center" style="padding:10px;color:white;">
 
		  <label class="active"><a  href="#">Home</a></label>
		   <label ><a   href="MOVIES.php">Movies</a></label>
		   <label ><a href="VIDIOS.php">Videos</a></label>
		   <label ><a href="SERIES.php">Series</a></label>
		  
		  <label ><a  href="CONTACT.php">Contact</a></label>
		  
		
		
		</div>

  <div align="center"class="back-to-top-link"><a href="#top" id="myBtn" ><span class="arrow"></span>Top</a></div>
  
    <div align="center">
         <p>copyright myweb 2017</p>
    
  </div>
</div>
</body>
</html>