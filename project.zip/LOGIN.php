<html>
  <head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <!-- Material Design Lite -->
    <script src="https://code.getmdl.io/1.3.0/material.min.js"></script>
	 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://code.getmdl.io/1.3.0/material.indigo-pink.min.css">
    <!-- Material Design icon font -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
	
	<script langauage = "javascript">
         function showMessage(value) {
            document.getElementById("message").innerHTML = value;
         }	  
      </script>
  </head>
  <body>
  	<!--header-->
    <div class = "mdl-layout mdl-js-layout mdl-layout--fixed-header">
         <header class = "mdl-layout__header">
            <div class = "mdl-layout__header-row">
               <!-- Title -->
               <span class = "mdl-layout-title">My Web</span>
               <!-- Add spacer, to align navigation to the right -->
               <div class = "mdl-layout-spacer"></div>
               <!-- Navigation -->
               <nav class = "mdl-navigation">
                  <a class = "mdl-navigation__link" href = "index.php" 
                     style = "color:white">HOME</a>
                  <a class = "mdl-navigation__link" href = "MOVIES.php" 
                     style = "color:white">MOVIES</a>
				  <a class = "mdl-navigation__link" href = "SERIES.php" 
                     style = "color:white">SERIES</a>
                  <a class = "mdl-navigation__link" href = "VIDEOS.php" 
                     style = "color:white">VIDEOS</a>
				  <a class = "mdl-navigation__link" href = "CONTACT.php" 
                     style = "color:white">CONTACT</a>
				  <a class = "mdl-navigation__link" href = "LOGIN.php" 
                     style = "color:white">LOGIN/SIGNUP</a>
               </nav>
            </div>
         </header>
	
	<!--content-->
			 <div class="container">
		     <main class = "mdl-layout__content"> 
		
			 <div class = "mdl-tabs mdl-js-tabs">
					   <div class = "mdl-tabs__tab-bar">
						  <a href = "#login-panel" class = "mdl-tabs__tab is-active" style="text-decoration:none;">Login</a>
						  <a href = "#signup-panel" class = "mdl-tabs__tab" style="text-decoration:none;">Signup</a>
					   </div>
			
					
		
		
					<div class = "mdl-tabs__panel is-active" id = "login-panel">
						<div class="container" style="margin-top:20px;"  align="center">
							
							<div class = "wide-card mdl-card mdl-shadow--2dp" style="width: 80%;">
                 				<div class = "mdl-card__supporting-text">
							
								
					  
									<div class="row">
										<div class="col-md-12">
											  <div class = "mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
												
												 <input class = "mdl-textfield__input" type = "email" pattern = "[a-zA-Z0-9._\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]" id = "email" name="user">
												 <label class = "mdl-textfield__label" for = "email">Username</label>
												 <span class = "mdl-textfield__error">Valid username required!</span>
											  </div>
										</div>
									</div>
									<div class="row">
										<div class="col-md-12">
												<div class = "mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
							 
													<input class = "mdl-textfield__input" type = "password" id = "pswd" name="pwd">
													<label class = "mdl-textfield__label" for = "password">Password</label>
												</div>
										</div>
									</div>
							 
								  
									<div class="row">
										<div class="col-md-6 col-xs-6"  align="right">
												<div  >
													 
																<input  type = "checkbox" id = "checkbox" class = "mdl-checkbox__input" checked>Remember me

												</div>	  
										</div>
												
										<div class="col-md-6 col-xs-6" align="left">
														<a href="forgotpassword.php">Forgot Password?</a>
										</div>
												
									</div>
											
									<div class="row">
										<div class="col-md-12">
												</br></br>
													<button class = "mdl-button  mdl-button--colored mdl-js-button mdl-button--raised mdl-js-ripple-effect">  Login</button>
											</div>
									</div>

									<div class="row">
										<div class="col-md-12">
											 <h5>Or</h5>
										</div>
								</div>
									
									
									<div class="row">
										<div class="col-md-12">
												 <button class = "mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect " style="margin-right :20px;">  Login With Google</button>
												 
												 <button class = "mdl-button  mdl-button--colored mdl-js-button mdl-button--raised mdl-js-ripple-effect"> Login with  Facebook</button>
										</div>
									</div>
										
								</div>
							</div>		
							
						</div> 
					</div>
				

				
			    <div class = "mdl-tabs__panel" id = "signup-panel">
                 	<div class="container" style="margin-top:20px; " align="center" >
                 		<div class = "wide-card mdl-card mdl-shadow--2dp" style="width: 80%;">
                 			<div class = "mdl-card__supporting-text">
                 				<div class="row">
										<div class="col-md-12">
											  <div class = "mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
												
												 <input class = "mdl-textfield__input" type = "text" pattern = "a-zA-Z" id = "usrname">
												 <label class = "mdl-textfield__label" for = "usrname">Name</label>
												 <span class = "mdl-textfield__error">Numbers are not allowed in name!</span>
											  </div>
										</div>
								</div>


								<div class="row">
										<div class="col-md-12">
											  <div class = "mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
												
												 <input class = "mdl-textfield__input" type = "email" pattern = "[^@\s]+@[^@\s]+\.[^@\s]+" id = "email">
												 <label class = "mdl-textfield__label" for = "email">E-Mail id</label>
												 <span class = "mdl-textfield__error">Valid E-mail id required!</span>
											  </div>
										</div>
								</div>

								<div class="row">
										<div class="col-md-12">
												<div class = "mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
							 
													<input class = "mdl-textfield__input" type = "password" id = "password">
													<label class = "mdl-textfield__label" for = "password">Password</label>
												</div>
										</div>
								</div>

								<div class="row">
										<div class="col-md-12">
												<div class = "mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
							 
													<input class = "mdl-textfield__input" type = "password" id = "confirmpassword">
													<label class = "mdl-textfield__label" for = "confirmpassword">Confirm Password</label>
												</div>
										</div>
								</div>


								<div class="row">
										<div class="col-md-12">
												</br></br>
													<button class = "mdl-button  mdl-button--colored mdl-js-button mdl-button--raised mdl-js-ripple-effect"> Signup</button>
										</div>
								</div>


								<div class="row">
										<div class="col-md-12">
											 <h5>Or</h5>
										</div>
								</div>
									
									
									<div class="row">
										<div class="col-md-12">
												 <button class = "mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect " style="margin-right :20px;">  Signup Google</button>
												 
												 <button class = "mdl-button  mdl-button--colored mdl-js-button mdl-button--raised mdl-js-ripple-effect">  Signup with Facebook</button>
										</div>
							
									</div>
							</div>		
						</div>	
                 	</div>
				 
				 
				 
                </div>
			   </div>
			  </main> 
			  <p><br><br><br></p>
		</div>
	
	

	<!--footer-->

	<footer class = "mdl-mini-footer">
               <div class = "mdl-mini-footer__left-section">
                  <div class = "mdl-logo">
                     Copyright Information
                  </div>
                  <ul class = "mdl-mini-footer__link-list">
                     <li><a href = "contact.php">Help</a></li>
          			
                  </ul>
               </div>
               
               <div class = "mdl-mini-footer__right-section">
                    <!--Facebook-->
				<button type="button" class="btn btn-fb"><i class="fa fa-facebook left"></i> Facebook</button>
				<!--Twitter-->
				<button type="button" class="btn btn-tw"><i class="fa fa-twitter left"></i> Twitter</button>
				<!--Google +-->
				<button type="button" class="btn btn-gplus"><i class="fa fa-google-plus left"></i> Google +</button>
               </div>
            
            </footer>
	</div>
  </body>
</html>