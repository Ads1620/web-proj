<!DOCTYPE html>
  <html>
    <head>
      <!--Import Google Icon Font-->
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
	  
      <!--Import materialize.css-->
      <link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>

      
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    </head>

    <body>
	 <nav class="#1565c0 blue darken-3"> 
    <div class="nav-wrapper">
	
      <a href="#" class="brand-logo" style="margin-left:15px;">My Web</a>
      <a href="#" data-activates="mobile-demo" class="button-collapse"><i class="material-icons">menu</i></a>
      <ul id="nav-mobile" class="right hide-on-med-and-down">
        <li><a href="index.php">Home</a></li>
        <li><a href="">Movies</a></li>
        <li><a href="collapsible.html">Videos</a></li>
		<li><a href="collapsible.html">Series</a></li>
		<li><a href="collapsible.html">Contact</a></li>
		<li class="active"><a href="collapsible.html">Login/Sign Up</a></li>
      </ul>
      <ul class="side-nav" id="mobile-demo">
        <li><a href="sass.html">Sass</a></li>
        <li><a href="badges.html">Components</a></li>
        <li><a href="collapsible.html">JavaScript</a></li>
      </ul>
    
	</div>
	</nav>
	
	<div class="container">
    <div class="col s6">
      <ul class="tabs center hide-on-med-and-down">
        <li class="tab col s6"><a class="active"  href="#login-panel">Login</a></li>
        <li class="tab col s6"><a href="#sign-up">Sign Up</a></li>
        
        
      </ul>
	  <div class="card-panel">
	  <div class = "mdl-tabs__panel is-active" id = "login-panel">
	  <div class="row">
	  <div class="col s6 l6">
    <form >
      <div class="row">
        <div class="input-field col s12">
          <input  id="Username" type="text" class="validate">
          <label for="Username">Username</label>
        </div>
		</div>
		<div class="row">
        <div class="input-field col s12">
          <input id="Password" type="text" class="validate">
          <label for="Password">Password</label>
        </div>
      </div>
	  <div class="row">
	   <div class="col s3 l6">
      <input type="checkbox" class="filled-in" id="filled-in-box"  />
      <label for="filled-in-box">Remember Me</label>
     </div>
	 <div class="col s3 l6">
	    <a href="#">Forgot Password?</a>
	 </div>
	 </div>
	  <div class="row" align="center">
	  <div class="col s6 " >
	  <a class="waves-effect waves-light btn #1565c0 blue darken-3" >Login</a>
	  </div>
	  </div>
      
      
      
      
    </form>
	</div>
	<div class="col s6 l6 center " style="margin-top:50px;">
	<div  class="row">
	   <a class="waves-effect waves-light btn social google">
          <i class="fa fa-google"></i> Google</a>
		 </div>
     <div class="row">		 
		  <a class="waves-effect waves-light btn social facebook">
           <i class="fa fa-facebook"></i> facebook</a>
      </div>
	  <a class="waves-effect waves-light btn social twitter">
       <i class="fa fa-twitter"></i>twitter</a>
	</div>
  </div>
	  </div>
	  </div>
	  
   </div>
   
  </div>
	
	
	
	
	
      <!--Import jQuery before materialize.js-->
      <script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
      <script type="text/javascript" src="js/materialize.min.js"></script>
	  <script type="text/javascript">
	  $(document).ready(function(){ $(".button-collapse").sideNav();})</script>
    </body>
  </html>
        